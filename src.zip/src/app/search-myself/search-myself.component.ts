import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { VoterService } from '../voter.service';

@Component({
  selector: 'app-search-myself',
  templateUrl: './search-myself.component.html',
  styleUrls: ['./search-myself.component.css']
})
export class SearchMyselfComponent implements OnInit {
message;
details;

  constructor(private voterService:VoterService,
    private router:Router) { }
  
    searchMyself(searchMyselfMyForm){

      let data = searchMyselfMyForm.form.value;
     
      
          console.log(data);
  
      this.voterService.searchMyself(data).subscribe((res)=>{
        console.log(res);
        
        this.details=res;
        if(this.details.status=="true")
        {
          this.message="Your name is find in VoterList";

        }
        else if(this.details.status=null)
        {
          this.message="your Request is pending or rejected plzz check your email";
        }
      this.router.navigate(['searchMyself']);
  
  
      
      },(error)=>{
        this.message="your Request is pending or rejected plzz check your email";
      }
      )
    }

  ngOnInit() {
  }

}
