import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import {RouterModule} from '@angular/router'
import {FormsModule} from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminDashComponent } from './admin-dash/admin-dash.component';
import { HomeComponent } from './home/home.component';
import { VoterRegistrationComponent } from './voter-registration/voter-registration.component';
import { EditByAdminComponent } from './edit-by-admin/edit-by-admin.component';
import { TrackStatusComponent } from './track-status/track-status.component';
import { SearchMyselfComponent } from './search-myself/search-myself.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { OtpComponent } from './otp/otp.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { UpdateMyselfComponent } from './update-myself/update-myself.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    DashboardComponent,
    AdminDashComponent,
    HomeComponent,
    VoterRegistrationComponent,
    EditByAdminComponent,
    TrackStatusComponent,
    SearchMyselfComponent,
    ForgotpasswordComponent,
    ResetpasswordComponent,
    OtpComponent,
    AboutComponent,
    ContactComponent,
    UpdateMyselfComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:"",component:HomeComponent},
      {path:"register",component:RegisterComponent},
      {path:"login",component:LoginComponent},
      {path:"dash",component:DashboardComponent},
      {path:"adminDisplay",component:AdminDashComponent},
      {path:"home",component:HomeComponent},
      {path:"voterRegistration",component:VoterRegistrationComponent},
      {path:'edit/:regId',component:EditByAdminComponent},
      {path:"trackStatus",component:TrackStatusComponent},
      {path:"searchMyself",component:SearchMyselfComponent},
      {path:"forgot",component:ForgotpasswordComponent},
      {path:"otp",component:OtpComponent},
      {path:"resetpassword",component:ResetpasswordComponent},
      {path:"about",component:AboutComponent},
      {path:"contact",component:ContactComponent},
      {path:"update",component:UpdateMyselfComponent}



    ])
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
