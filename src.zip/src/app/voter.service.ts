import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VoterService {
  baseurl="http://localhost:8087/DacAug19/voter/register/";
  constructor(private http:HttpClient) { }

  voterRegistration(voter,uid){

    return this.http.post("http://localhost:8087/DacAug19/voter/register/"+uid,voter);

  }

  getData()
  {
    return this.http.get("http://localhost:8087/DacAug19/voter/registers");
  }

  trackStatus(data)
  {
    return this.http.put("http://localhost:8087/DacAug19/voter/search",data);
  }
  searchMyself(data)
  {
    return this.http.put("http://localhost:8087/DacAug19/voter/search",data);
  }
  updateMyself(data)
  {
    return this.http.put("http://localhost:8087/DacAug19/voter/searchForUpdate",data);
  }

}
